package fr.alaska.launcher;
public abstract class LauncherSettings extends LauncherMedia {protected void updateClock(){java.text.SimpleDateFormat h=new java.text.SimpleDateFormat("HH:mm",java.util.Locale.FRANCE),d=new java.text.SimpleDateFormat("EEEE d MMMM",java.util.Locale.FRANCE);clock.setText(h.format(new java.util.Date()));date.setText(d.format(new java.util.Date()));}}
