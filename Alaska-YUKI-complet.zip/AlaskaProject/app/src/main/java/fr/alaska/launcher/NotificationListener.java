package fr.alaska.launcher;
import android.service.notification.NotificationListenerService;import android.service.notification.StatusBarNotification;import android.util.Log;
public class NotificationListener extends NotificationListenerService {@Override public void onListenerConnected(){super.onListenerConnected();Log.i("AlaskaMedia","Accès aux notifications connecté");}@Override public void onNotificationPosted(StatusBarNotification s){/* MediaSessionManager lit les métadonnées des lecteurs actifs. */}}
