package fr.alaska.launcher;

import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.SharedPreferences;
import android.net.Uri;

public abstract class LauncherUi extends LauncherBase {
    protected LinearLayout root, header, body, rail, center;
    protected TextView clock, date, weather, speed, track, artist;
    protected ImageView cover; protected WebView carView;
    private String selectedPage="home";
    protected void buildUi() {
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.rgb(13,19,25));
        header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(18,6,18,6);header.setBackgroundColor(Color.rgb(24,34,43));
        clock=label("--:--",27);date=label("--",12);weather=label("--",15);speed=label("-- km/h",18);
        header.addView(clock,weight(1.1f));header.addView(date,weight(1.2f));header.addView(weather,weight(1));header.addView(speed,weight(1));root.addView(header,new LinearLayout.LayoutParams(-1,62));
        body=new LinearLayout(this);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        rail=new LinearLayout(this);rail.setOrientation(1);rail.setPadding(5,8,5,8);rail.setBackgroundColor(Color.rgb(22,31,39));body.addView(rail,new LinearLayout.LayoutParams(82,-1));
        addNav("⌂","Accueil",()->showHome());addNav("▦","Applis",()->showApps());addNav("◉","Voiture",()->showCar());addNav("⚙","Réglages",()->showSettings());
        center=new LinearLayout(this);center.setOrientation(1);center.setPadding(14,8,14,8);body.addView(center,new LinearLayout.LayoutParams(0,-1,1));
        carView=new WebView(this);WebSettings ws=carView.getSettings();ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(false);ws.setAllowFileAccess(true);ws.setBlockNetworkLoads(true);ws.setMediaPlaybackRequiresUserGesture(true);carView.setWebViewClient(new WebViewClient());carView.loadUrl("file:///android_asset/golf.html");
        center.addView(carView,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout media=new LinearLayout(this);media.setGravity(Gravity.CENTER_VERTICAL);media.setPadding(10,3,10,3);media.setBackgroundColor(Color.rgb(24,34,43));
        cover=new ImageView(this);cover.setImageResource(android.R.drawable.ic_media_play);media.addView(cover,new LinearLayout.LayoutParams(38,38));
        LinearLayout labels=new LinearLayout(this);labels.setOrientation(1);track=label("Aucune lecture",13);artist=label("--",11);labels.addView(track);labels.addView(artist);media.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        media.addView(mediaButton("|◀",()->mediaAction("previous")));media.addView(mediaButton("▶/Ⅱ",()->mediaAction("play")));media.addView(mediaButton("▶|",()->mediaAction("next")));center.addView(media,new LinearLayout.LayoutParams(-1,54));
        setContentView(root);showHome();
    }
    protected TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);return t;}
    protected LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,-2,w);}
    protected void addNav(String glyph,String name,Runnable r){Button b=new Button(this);b.setText(glyph+"\n"+name);b.setTextSize(10);b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.TRANSPARENT);b.setOnClickListener(v->r.run());rail.addView(b,new LinearLayout.LayoutParams(-1,0,1));}
    private Button mediaButton(String text,Runnable action){Button b=new Button(this);b.setText(text);b.setTextSize(10);b.setOnClickListener(v->action.run());return b;}
    protected void showHome(){selectedPage="home";center.removeAllViews();center.addView(carView,new LinearLayout.LayoutParams(-1,0,1));addMediaBar();}
    protected void showCar(){selectedPage="car";center.removeAllViews();center.addView(carView,new LinearLayout.LayoutParams(-1,-1));}
    private void addMediaBar(){LinearLayout media=new LinearLayout(this);media.setGravity(Gravity.CENTER_VERTICAL);media.addView(label("♫  ",18));media.addView(track,new LinearLayout.LayoutParams(0,-2,1));media.addView(mediaButton("⏮",()->mediaAction("previous")));media.addView(mediaButton("⏯",()->mediaAction("play")));media.addView(mediaButton("⏭",()->mediaAction("next")));center.addView(media,new LinearLayout.LayoutParams(-1,46));}
    protected void showApps(){selectedPage="apps";center.removeAllViews();ScrollView sc=new ScrollView(this);GridLayout grid=new GridLayout(this);grid.setColumnCount(5);for(ApplicationInfo a:getPackageManager().getInstalledApplications(0)){if(getPackageManager().getLaunchIntentForPackage(a.packageName)==null||a.packageName.equals(getPackageName()))continue;LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setGravity(Gravity.CENTER);item.setPadding(3,8,3,8);ImageView icon=new ImageView(this);try{icon.setImageDrawable(a.loadIcon(getPackageManager()));}catch(Exception ignored){}item.addView(icon,new LinearLayout.LayoutParams(48,48));TextView name=label(a.loadLabel(getPackageManager()).toString(),10);name.setGravity(Gravity.CENTER);item.addView(name);item.setOnClickListener(v->{Intent i=getPackageManager().getLaunchIntentForPackage(a.packageName);if(i!=null)startActivity(i);});grid.addView(item,new GridLayout.LayoutParams());}sc.addView(grid);center.addView(sc,new LinearLayout.LayoutParams(-1,-1));}
    protected void showSettings(){selectedPage="settings";new android.app.AlertDialog.Builder(this).setTitle("Réglages Alaska").setItems(new String[]{"Couleur de la voiture","Qualité 3D","Écran de veille","Choisir l'application GPS","Autoriser l'accès aux médias","Autoriser la localisation","À propos"},(d,w)->{if(w==0)chooseColor();else if(w==1)chooseQuality();else if(w==2)toggleScreensaver();else if(w==3)chooseNavigation();else if(w==4)startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));else if(w==5)requestLocationPermission();else new android.app.AlertDialog.Builder(this).setMessage(ClientConfig.NOM_APP+" "+ClientConfig.VERSION+"\n"+ClientConfig.VEHICULE+"\nAutoradio "+ClientConfig.AUTORADIO).setPositiveButton("OK",null).show();}).show();}
    private void chooseColor(){String[] names={"Gris ardoise","Noir","Bleu nuit","Rouge"};String[] vals={"#4A5A62","#20252A","#263B58","#733B3B"};new android.app.AlertDialog.Builder(this).setTitle("Couleur voiture").setItems(names,(d,w)->{getPreferences(0).edit().putString("carColor",vals[w]).apply();carView.evaluateJavascript("window.setCarColor && window.setCarColor('"+vals[w]+"')",null);}).show();}
    private void chooseQuality(){String[] q={"Économie (recommandé)","Équilibré","Détaillé"};new android.app.AlertDialog.Builder(this).setTitle("Qualité 3D").setItems(q,(d,w)->{getPreferences(0).edit().putInt("quality",w).apply();carView.evaluateJavascript("window.setQuality && window.setQuality("+w+")",null);}).show();}
    private void toggleScreensaver(){boolean on=getPreferences(0).getBoolean("screensaver",true);getPreferences(0).edit().putBoolean("screensaver",!on).apply();Toast.makeText(this,!on?"Écran de veille activé":"Écran de veille désactivé",Toast.LENGTH_SHORT).show();}
    private void chooseNavigation(){java.util.ArrayList<String> names=new java.util.ArrayList<>(),pkgs=new java.util.ArrayList<>();for(ApplicationInfo a:getPackageManager().getInstalledApplications(0)){if(getPackageManager().getLaunchIntentForPackage(a.packageName)!=null&&(a.packageName.toLowerCase().contains("map")||a.packageName.toLowerCase().contains("nav")||a.packageName.toLowerCase().contains("waze"))){names.add(a.loadLabel(getPackageManager()).toString());pkgs.add(a.packageName);}}if(names.isEmpty()){Toast.makeText(this,"Aucune application GPS détectée",Toast.LENGTH_LONG).show();return;}new android.app.AlertDialog.Builder(this).setTitle("Application GPS").setItems(names.toArray(new String[0]),(d,w)->{getPreferences(0).edit().putString("navigation",pkgs.get(w)).apply();Intent i=getPackageManager().getLaunchIntentForPackage(pkgs.get(w));if(i!=null)startActivity(i);}).show();}
    protected void mediaAction(String action){android.content.Intent i=new android.content.Intent("fr.alaska.MEDIA_"+action.toUpperCase(java.util.Locale.ROOT));sendBroadcast(i);}
    protected void showScreenSaver(){if(!getPreferences(0).getBoolean("screensaver",true))return;runOnUiThread(()->{if(!isFinishing()){new android.app.AlertDialog.Builder(this).setMessage(clock.getText()+"\n"+date.getText()).setCancelable(true).show();}});}
}
