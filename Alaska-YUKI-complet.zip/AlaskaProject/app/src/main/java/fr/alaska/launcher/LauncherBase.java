package fr.alaska.launcher;
import android.Manifest;import android.app.Activity;import android.content.pm.PackageManager;import android.os.Build;import android.os.Bundle;import android.view.WindowManager;
public abstract class LauncherBase extends Activity {
 protected static final int REQ_LOCATION=41;
 @Override protected void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);getWindow().getDecorView().setSystemUiVisibility(5894|1024|512|4096);}
 protected boolean hasLocationPermission(){return Build.VERSION.SDK_INT<23||checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
 protected void requestLocationPermission(){if(Build.VERSION.SDK_INT>=23&&!hasLocationPermission())requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION);}
}
