package fr.alaska.launcher;

/** Valeurs à personnaliser pour chaque autoradio/client. */
public final class ClientConfig {
    public static final String NOM_APP = "Alaska";
    public static final String PACKAGE = "fr.alaska.launcher";
    public static final String VERSION = "1.0";
    public static final String VEHICULE = "VW Golf IV 2001";
    public static final String AUTORADIO = "F9212A";
    public static final String COULEUR_PAR_DEFAUT = "#4A5A62";
    public static final String VILLE_METEO = ""; // Facultatif : ville de secours
    private ClientConfig() {}
}
