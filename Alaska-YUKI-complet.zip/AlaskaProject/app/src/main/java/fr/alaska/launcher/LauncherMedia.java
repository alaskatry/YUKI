package fr.alaska.launcher;

import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.media.MediaMetadata;
import android.util.Log;
import android.graphics.Bitmap;
import android.view.KeyEvent;
import java.util.List;

public abstract class LauncherMedia extends LauncherSensors {
    private MediaController activeController;

    protected void refreshMedia() {
        try {
            MediaSessionManager manager = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
            List<MediaController> sessions = manager.getActiveSessions(new android.content.ComponentName(this, NotificationListener.class));
            if (sessions.isEmpty()) {
                activeController = null;
                track.setText("Aucune lecture détectée");
                artist.setText("--");
                cover.setImageResource(android.R.drawable.ic_media_play);
                return;
            }
            activeController = sessions.get(0);
            MediaMetadata metadata = activeController.getMetadata();
            if (metadata != null) {
                String title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE);
                String by = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST);
                track.setText(title == null ? "--" : title);
                artist.setText(by == null ? "--" : by);
                Bitmap art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if (art == null) art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (art != null) cover.setImageBitmap(art);
            }
        } catch (SecurityException e) {
            activeController = null;
            Log.w("AlaskaMedia", "Autoriser l'accès aux notifications", e);
        }
    }

    @Override protected void mediaAction(String action) {
        if (activeController == null) {
            android.widget.Toast.makeText(this, "Autorisez l'accès aux notifications dans les réglages", android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        int key;
        if ("previous".equals(action)) key = KeyEvent.KEYCODE_MEDIA_PREVIOUS;
        else if ("next".equals(action)) key = KeyEvent.KEYCODE_MEDIA_NEXT;
        else {
            PlaybackState state = activeController.getPlaybackState();
            key = state != null && state.getState() == PlaybackState.STATE_PLAYING
                    ? KeyEvent.KEYCODE_MEDIA_PAUSE : KeyEvent.KEYCODE_MEDIA_PLAY;
        }
        long now = android.os.SystemClock.uptimeMillis();
        activeController.dispatchMediaButtonEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, key, 0));
        activeController.dispatchMediaButtonEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, key, 0));
    }
}
