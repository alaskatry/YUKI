# Alaska — launcher Android F9212A

Projet Android Java, paysage, minSdk 23, compileSdk 33, targetSdk 29, AGP 7.4.2 / Gradle 7.5 / JDK 17. Chaîne demandée : LauncherBase → LauncherUi → LauncherSensors → LauncherMedia → LauncherSettings → MainActivity.

## Fonctions présentes
- Interface native paysage : heure/date, météo Open-Meteo et vitesse GPS (valeurs `--` si absentes).
- Grille des applications installées et lancement au toucher.
- WebView local : modèle 3D de Golf IV construit avec primitives Three.js, plateau tournant, interaction tactile, couleur et réglage qualité. Three.js est téléchargé pendant le build puis embarqué dans l'APK : aucun appel réseau pour afficher la voiture.
- Lecture des métadonnées des sessions média Android, titre/artiste/pochette si le lecteur les fournit, et commandes de transport diffusées via intents (prise en charge variable selon lecteur).
- Réglages de base : couleur, qualité, écran de veille, raccourci de navigation, permissions et À propos.

## Construire l'APK
GitHub Actions lance automatiquement `Build Alaska APK` à chaque push sur `main`. Depuis le téléphone : dépôt → Actions → Build Alaska APK → dernière exécution verte → Artifacts → `Alaska-debug-apk`. Le fichier est `app-debug.apk`.

## À terminer avant commercialisation
- Tester sur le F9212A réel (WebView/WebGL, GPS, permissions, commandes médias, résolution et fluidité).
- La géolocalisation météo de secours nécessite de renseigner `VILLE_METEO` dans `ClientConfig.java`.
- Les commandes médias dépendent du lecteur et doivent être validées sur l'autoradio.
- Écran de veille et sélection du GPS sont des bases simples, pas une configuration avancée complète.
- Le modèle 3D est une interprétation basse-poly en code, pas une reproduction photoréaliste certifiée.
- Configurer une clé de signature stable dans les secrets GitHub avant diffusion commerciale ; ne jamais committer de clé privée. L'APK debug ne convient pas à la vente.

## Personnaliser un client
Modifier uniquement les constantes de `app/src/main/java/fr/alaska/launcher/ClientConfig.java` autant que possible.
